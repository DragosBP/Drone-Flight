#include "teme/tema1/tank.h"
#include "teme/tema1/tema1_object2D.h"

#include <vector>
#include <iostream>

using namespace std;
using namespace teme;

Tank::Tank(glm::vec3 tank_start, float tank_speed, int tank_size, glm::vec3 bullet_speed, string name)
{
    this->tank_pos = tank_start;
    this->tank_speed = tank_speed;
    this->tank_size = tank_size;
    this->weapon_rotation = 0;
    this->name = name;

    this->body = tema1_object2D::CreateTank(
        name + "_body",
        tank_start,
        tank_size,
        0
    );


    this->weapon = tema1_object2D::CreateGun(
        name + "_weapon",
        tank_start,
        tank_size,
        glm::vec3(0.017f, 0.017f, 0.016f)
    );

    this->trajectory = tema1_object2D::CreateGun(
        name + "_trajectory",
        tank_start,
        tank_size,
        glm::vec3(1.0f, 1.0f, 1.0f)
    );

    this->bullet = tema1_object2D::CreateCircle(
        name + "_bullet",
        tank_start,
        tank_size * 3,
        glm::vec3(1.0f, 1.0f, 1.0f)
    );

    this->power = 100;
    this->bullet_speed = bullet_speed;
    this->bullet_pos = tank_start;
    this->bullet_start = glm::vec3(0);
    this->shot = false;
}

Tank::~Tank()
{

}

void Tank::CalculateTankPosition(vector<float> height_map, float square_terrain_length) {
    glm::vec3 A = glm::vec3
    (
        tank_pos.x,
        height_map[floor(tank_pos.x / square_terrain_length)],
        0
    );

    glm::vec3 B = glm::vec3
    (
        tank_pos.x + square_terrain_length,
        height_map[floor((tank_pos.x + square_terrain_length) / square_terrain_length)],
        0
    );

    float t = (tank_pos.x - A.x) / (B.x - A.x);
    float tankY = A.y + t * (B.y - A.y);

    glm::vec3 diff = B - A;
    float rotation = atan2(diff.y, diff.x);

    tank_pos = glm::vec3(tank_pos.x, tankY, rotation);
}

float Tank::CalculateTrajectory(float x) {
    power = 2.0f;
    float direction = this->weapon_rotation + 90;
    // ydr = y-st + direction * (x-dr - x-st) 
    return x * RADIANS(direction) * power;
}