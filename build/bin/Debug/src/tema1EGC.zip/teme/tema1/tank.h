#pragma once

#include "components/simple_scene.h"

namespace teme
{
	class Tank
	{
	public:
		Tank(glm::vec3 tank_start, float tank_speed, int tank_size, glm::vec3 bullet_speed, std::string name);
		~Tank();
	
		void CalculateTankPosition(std::vector<float> height_map, float square_terrain_length);
		float CalculateTrajectory(float x);

		std::string name;
		
		glm::vec3 tank_pos;
		float tank_speed;
		int tank_size;
		
		float weapon_rotation;
		float power;
		
		glm::vec3 bullet_speed;
		glm::vec3 bullet_pos;
		glm::vec3 bullet_start;
		bool shot;

		Mesh* body;
		Mesh* weapon;
		Mesh* trajectory;
		Mesh* bullet;
	};

}