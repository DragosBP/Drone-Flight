#include "teme/tema1/tema1.h"

#include <vector>
#include <iostream>

#include "teme/tema1/tema1_transform2D.h"
#include "teme/tema1/tema1_object2D.h"

using namespace std;
using namespace teme;


/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


Tema1::Tema1() : player1(nullptr)
{

}


Tema1::~Tema1()
{
    delete player1;
}

void Tema1::Init()
{
    glm::ivec2 resolution = window->GetResolution();
    auto camera = GetSceneCamera();
    camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
    camera->SetPosition(glm::vec3(0, 0, 50));
    camera->SetRotation(glm::vec3(0, 0, 0));
    camera->Update();
    GetCameraInput()->SetActive(false);

    int screen_width = resolution.x;

    // Init terrain
    g = -0.6f;
    terrain_density = 0.01f;
    terrain_start = 0;
    square_terrain_length = screen_width / 2000.0f;

    glm::vec3 corner = glm::vec3(0, 0, 0);
    Mesh* square1 = tema1_object2D::CreateSquare(
        "square_terrain",
        corner,
        1.0f,
        glm::vec3(0.843f, 0.874f, 0.129f),
        true
    );
    AddMeshToList(square1);
    InitHeightMap(screen_width);


    // Variables of the tanks
    power = 20;
    
    float tank_speed = 100.0f;
    int tank_size = 1;
    glm::vec3 bullet_speed = glm::vec3(0, 0, 0);

    // Init the first tank
    player1 = new Tank(
        corner, 
        tank_speed, 
        tank_size,
        bullet_speed,
        "player1"
    );
    AddMeshToList(player1->body);
    AddMeshToList(player1->weapon);
    AddMeshToList(player1->trajectory);
    AddMeshToList(player1->bullet);
    player1->tank_pos.x = 130;
    player1->CalculateTankPosition(height_map, square_terrain_length);
    

}

float TerrainFunction(float x, float t) {
    // Valori t: (rand(0...1000) * 2 + 2000) / 10000
    // Terenul ridicat cu un 6 si inmultit cu 20
    // capat stanga: st = rand(0...150), capat dreapta: dr = st + 30

    float y =
        sin(t * x) +
        0.6f * sin(t * 2.0f * x) +
        0.9f * sin(t * 1.4f * x) +
        1.5f * sin(t * 0.3f * x) +
        1.2f * sin(t * 0.8f * x) +
        2.0f * sin(t * 0.2f * x) +
        1.7f * sin(t * 1.2f * x);

    return (y + 6.0f) * 20;
}

void Tema1::InitHeightMap(int screen_width) {
    float height;
    float i;

    for (i = 0; i < screen_width; i += square_terrain_length) {
        height = TerrainFunction(i + terrain_start, terrain_density);
        height_map.push_back(height);
    }

    height = TerrainFunction(i + terrain_start, terrain_density);
    height_map.push_back(height);
}

void Tema1::FrameStart()
{
    glClearColor(0.588f, 0.8f, 0.905f, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::GenerateTerrain() {
    float height_st, height_dr;
    float i;
    height_st = height_map[0];

    for (i = 0; i < height_map.size() - 1; i++) {
        height_dr = height_map[i + 1];

        modelMatrix = glm::mat3(1);
        modelMatrix *= tema1_transform2D::Translate(i * square_terrain_length, height_st);
        modelMatrix *= tema1_transform2D::Cut((height_dr - height_st) / square_terrain_length);
        modelMatrix *= tema1_transform2D::Translate(0, -max(height_dr, height_st));
        modelMatrix *= tema1_transform2D::Scale(square_terrain_length, max(height_dr, height_st));
        RenderMesh2D(meshes["square_terrain"], shaders["VertexColor"], modelMatrix);

        height_st = height_dr;
    }

}

void Tema1::Update(float deltaTimeSeconds)
{
    // Terrain
    GenerateTerrain();

    // Tank 
    modelMatrix = glm::mat3(1);
    modelMatrix *= tema1_transform2D::Translate(player1->tank_pos.x, player1->tank_pos.y);
    modelMatrix *= tema1_transform2D::Rotate(player1->tank_pos.z);
    RenderMesh2D(meshes["player1_body"], shaders["VertexColor"], modelMatrix);

    // Weapon
    modelMatrix = glm::mat3(1);
    modelMatrix *= tema1_transform2D::Translate(player1->tank_pos.x, player1->tank_pos.y);
    modelMatrix *= tema1_transform2D::Rotate(player1->tank_pos.z);

    modelMatrix *= tema1_transform2D::Translate(0, 28 * player1->tank_size);
    modelMatrix *= tema1_transform2D::Rotate(RADIANS(player1->weapon_rotation));
    modelMatrix *= tema1_transform2D::Translate(0, -28 * player1->tank_size);
    RenderMesh2D(meshes["player1_weapon"], shaders["VertexColor"], modelMatrix);

    // Trajectory
    float translateX = player1->tank_pos.x - 28 * player1->tank_size * sin(player1->tank_pos.z);
    float translateY = player1->tank_pos.y - 28 * player1->tank_size * (1 - cos(player1->tank_pos.z));
    
    float vX = cos(RADIANS(player1->weapon_rotation + 90) + player1->tank_pos.z) * player1->tank_size * power;
    float vY = sin(RADIANS(player1->weapon_rotation + 90) + player1->tank_pos.z) * player1->tank_size * power;

    int deltaT = 2; // TODO: add global variale
    for (int i = 1; i < 60; i += deltaT) {
        float addToX = vX * deltaT;
        float addToY = vY * deltaT + (g * deltaT * deltaT / 2);

        vY += g * deltaT;

        float rotate = atan2(addToY, addToX);
        
        translateX += addToX;
        translateY += addToY;

        modelMatrix = glm::mat3(1);
        modelMatrix *= tema1_transform2D::Translate(translateX, translateY);

        modelMatrix *= tema1_transform2D::Translate(0, 28 * player1->tank_size);
        modelMatrix *= tema1_transform2D::Rotate(rotate - RADIANS(90));
        modelMatrix *= tema1_transform2D::Scale(1, 0.1f);
        modelMatrix *= tema1_transform2D::Translate(0, -28 * player1->tank_size);

        RenderMesh2D(meshes["player1_trajectory"], shaders["VertexColor"], modelMatrix);

    }

    // Bullet
    float bullet_time = 20; // TODO: add global variale
    if (player1->shot) {
        float addToX = bullet_time * player1->bullet_speed.x * deltaTimeSeconds;
        float addToY = bullet_time * player1->bullet_speed.y * deltaTimeSeconds + (g * deltaTimeSeconds * deltaTimeSeconds / 2);
        
        player1->bullet_speed.y += bullet_time* g * deltaTimeSeconds;

        player1->bullet_pos += glm::vec3(addToX, addToY, 0);

        modelMatrix = glm::mat3(1);
        modelMatrix *= tema1_transform2D::Translate(player1->bullet_pos.x, player1->bullet_pos.y);

        RenderMesh2D(meshes["player1_bullet"], shaders["VertexColor"], modelMatrix);
    }
}


void Tema1::FrameEnd()
{
}


/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Tema1::OnInputUpdate(float deltaTime, int mods)
{
    if (window->KeyHold(GLFW_KEY_A)) {
        player1->tank_pos.x -= deltaTime * player1->tank_speed;
        player1->CalculateTankPosition(height_map, square_terrain_length);
    }
    if (window->KeyHold(GLFW_KEY_D)) {
        player1->tank_pos.x += deltaTime * player1->tank_speed;
        player1->CalculateTankPosition(height_map, square_terrain_length);
    }
    if (window->KeyHold(GLFW_KEY_W) && player1->weapon_rotation > -90) {
        player1->weapon_rotation -= deltaTime * player1->tank_speed;
    }
    if (window->KeyHold(GLFW_KEY_S) && player1->weapon_rotation < 90) {
        player1->weapon_rotation += deltaTime * player1->tank_speed;
    }
}


void Tema1::OnKeyPress(int key, int mods)
{
    // Add key press event
    if (key == GLFW_KEY_SPACE) {
        player1->shot = true;
        player1->bullet_pos = glm::vec3(
            player1->tank_pos.x + 28 * player1->tank_size * cos(RADIANS(90) + player1->tank_pos.z),
            player1->tank_pos.y + 28 * player1->tank_size * sin(RADIANS(90) + player1->tank_pos.z),
            0
        );
        player1->bullet_speed = glm::vec3(
            cos(RADIANS(player1->weapon_rotation + 90) + player1->tank_pos.z) * player1->tank_size * power,
            sin(RADIANS(player1->weapon_rotation + 90) + player1->tank_pos.z) * player1->tank_size * power,
            0
        );
    }
    if (key == GLFW_KEY_ENTER) {
        player1->shot = false;
    }
}


void Tema1::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event
}


void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
    printf("%d %d\n", mouseX, window->GetResolution().y - mouseY);
}


void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event
}


void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema1::OnWindowResize(int width, int height)
{
}
