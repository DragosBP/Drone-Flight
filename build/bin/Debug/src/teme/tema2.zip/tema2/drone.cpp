#pragma once

#include "teme/tema2/drone.h"
#include "teme/tema2/tema2_object3D.h"

using namespace teme;

std::vector<glm::vec3> InitPropelersPos(float size) {
	float length = size;
	float width = length / 10;
	float height = width;

	float deltaL = length / 2;
	float deltaW = width / 2;
	float deltaH = height / 2;

	std::vector<glm::vec3> propelers_pos = {
		glm::vec3(-(deltaL - deltaH), height + deltaH + height / 5, 0),
		glm::vec3(deltaL - deltaH, height + deltaH + height / 5, 0),
		glm::vec3(0, height + deltaH + height / 5, deltaL - deltaH),
		glm::vec3(0, height + deltaH + height / 5, -(deltaL - deltaH))
	};

	return propelers_pos;
}

Drone::Drone(std::string name, float size, glm::vec3 initial_pos, glm::vec3 initial_rot, float speed) {
	this->name = name;
	this->size = size;

	this->body = tema2_object3D::CreateDrone(name + "_body", size);
	this->position = initial_pos;

	this->speed = speed;
	this->acceleration = speed / 20;
	this->thrust = 0;
	this->rotation = initial_rot;
	this->max_thrust = 5 * speed;

	this->propeler = tema2_object3D::CreatePropeler(name + "_propeler", size);
	this->propelers_pos = InitPropelersPos(size);
	this->propeler_rotation = 0;

	this->colision_radius = size / 2;
}

Drone::~Drone() {

}

void Drone::Thrust(float delta, float pow) {
	thrust += pow * delta;
	if (abs(thrust) > max_thrust) {
		thrust = thrust < 0 ? -max_thrust : max_thrust;
	}
}

void Drone::Pitch(float delta) {
	rotation.x += delta * speed * 20;
	if (rotation.x >= 360) {
		rotation.x -= 360;
	}
	else if (rotation.x < 0) {
		rotation.x += 360;
	}
}

void Drone::Yaw(float delta) {
	rotation.y += delta * speed * 20;
	if (rotation.y >= 360) {
		rotation.y -= 360;
	}
	else if (rotation.y < 0) {
		rotation.y += 360;
	}
}

void Drone::Roll(float delta) {
	rotation.z += delta * speed * 20;
	if (rotation.z >= 360) {
		rotation.z -= 360;
	}
	else if (rotation.z < 0) {
		rotation.z += 360;
	}
}

void Drone::Move(float delta) {

	glm::vec3 tmp = glm::vec3(0, 0, 0);

	tmp.x += sin(RADIANS(-rotation.z + rotation.y));
	tmp.y += cos(RADIANS(rotation.x + rotation.y)) * cos(RADIANS(rotation.z + rotation.y));
	tmp.z += sin(RADIANS(rotation.x + rotation.y)) * cos(RADIANS(-rotation.z + rotation.y));

	position += tmp * thrust;
}

void Drone::RotatePropeler(float delta) {
	propeler_rotation += delta * speed * 16000 * thrust;
	if (propeler_rotation >= 360) {
		propeler_rotation -= 360;
	}
	else if (propeler_rotation < 0) {
		propeler_rotation += 360;
	}
}