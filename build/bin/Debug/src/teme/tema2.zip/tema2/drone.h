#pragma once

#include "components/simple_scene.h"


namespace teme
{
	class Drone
	{
	public:
		Drone::Drone(std::string name, float size, glm::vec3 initial_pos, glm::vec3 initial_rot, float speed);
		~Drone();

		void Thrust(float delta, float pow);
		void Pitch(float delta);
		void Yaw(float delta);
		void Roll(float delta);

		void Move(float delta);
		void RotatePropeler(float delta);

		std::string name;
		float size;

		Mesh* body;
		glm::vec3 position;
		
		float acceleration;
		float speed;
		float thrust;
		glm::vec3 rotation;
		float max_thrust;

		Mesh* propeler;
		std::vector<glm::vec3> propelers_pos;
		float propeler_rotation;

		float colision_radius;
	};
}
